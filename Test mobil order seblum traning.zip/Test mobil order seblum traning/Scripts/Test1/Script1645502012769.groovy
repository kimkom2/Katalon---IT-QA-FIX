import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

Mobile.startApplication('C:\\Users\\ho.hendy\\Downloads\\MobWo 1.1.0.9.2 dev.apk', true)

WebUI.delay(2)

Mobile.setText(findTestObject('Object Repository/Test 1/android.widget.EditText'), 'HermanMKT', 0)

WebUI.delay(2)

Mobile.setEncryptedText(findTestObject('Object Repository/Test 1/android.widget.EditText (1)'), 'p4y+y39Ir5OGQkBUoox0IA==', 
    0)

WebUI.delay(2)

Mobile.tap(findTestObject('Object Repository/Test 1/android.widget.Button - Login'), 0)

WebUI.delay(2)

Mobile.tap(findTestObject('Object Repository/Test 1/android.widget.LinearLayout'), 0)

WebUI.delay(2)

Mobile.tap(findTestObject('Object Repository/Test 1/android.widget.RelativeLayout'), 0)

WebUI.delay(2)

Mobile.tap(findTestObject('Object Repository/Test 1/android.widget.ImageView'), 0)

WebUI.delay(2)

Mobile.tap(findTestObject('Object Repository/Test 1/android.widget.CheckedTextView - Aplikasi Baru'), 0)

WebUI.delay(2)

Mobile.tap(findTestObject('Object Repository/Test 1/android.widget.Button - Selanjutnya'), 0)

WebUI.delay(2)

Mobile.tap(findTestObject('Object Repository/Test 1/android.widget.TextView - Pilih'), 0)

WebUI.delay(2)

Mobile.tap(findTestObject('Object Repository/Test 1/android.widget.CheckedTextView - Single'), 0)

WebUI.delay(2)

Mobile.tap(findTestObject('Test 1/android.widget.Button - Selanjutnya'), 0)

WebUI.delay(2)

Mobile.scrollToText('Nama Orang tua', FailureHandling.OPTIONAL)

WebUI.delay(2)

Mobile.tap(findTestObject('Test 2/android.widget.TextView - Status Kepemilikan Rumah'), 0)

Mobile.tap(findTestObject('Test 2/android.widget.TextView - Pilih (8)'), 0)

Mobile.setText(findTestObject('Test 2/android.widget.EditText (4)'), 'MILIK SENDIRI', 0)

Mobile.tap(findTestObject('Object Repository/Test 2/android.widget.TextView - MILIK SENDIRI'), 0)

WebUI.delay(2)

Mobile.tap(findTestObject('Object Repository/Test 2/android.widget.TextView - Tahun Menempati'), 0)

Mobile.tap(findTestObject('Test 2/android.widget.TextView - Pilih (9)'), 0)

Mobile.setText(findTestObject('Test 2/android.widget.EditText (5)'), '2018', 0)

Mobile.tap(findTestObject('Object Repository/Test 2/android.widget.TextView - 2018'), 0)

WebUI.delay(2)

Mobile.setText(findTestObject('Object Repository/Test 2/android.widget.EditText - Nama Orang tua'), 'Mamaku', 0)

Mobile.setText(findTestObject('Test 2/android.widget.EditText - No. Telp Orang tua'), '09123123', 0)

WebUI.delay(2)

Mobile.scrollToText('Domisili sesuai KTP', FailureHandling.OPTIONAL)

Mobile.tap(findTestObject('Object Repository/Test 1/android.widget.CheckBox - Domisili sesuai KTP'), 0)

Mobile.scrollToText('Selanjutnya', FailureHandling.OPTIONAL)

Mobile.tap(findTestObject('Test 2/android.widget.Button - Selanjutnya (2)'), 0)

